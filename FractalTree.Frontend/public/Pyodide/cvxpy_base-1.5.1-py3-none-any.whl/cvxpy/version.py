
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.5.1'
version = '1.5.1'
full_version = '1.5.1'
git_revision = '5bc7313'
commit_count = '5bc7313'
release = True
if not release:
    version = full_version
